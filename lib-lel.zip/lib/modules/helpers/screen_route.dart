import 'package:mqtt_client/mqtt_client.dart';

const MESSAGE_ROUTE = "message_route";
const SETTINGS_ROUTE = "settings_route";
const SUBSCRIBE_ROUTE = "subscribe_route";
const DASHBORAD_ROUTE = "dashborad_route";
const MESS_ROUTE = "sendmess_route";
const LIGHT_ROUTE = "light_route";
const LOGGING_ROUTE = "logging_route";
const Testing = "logging_route";
