import 'package:flutter/material.dart';

class DevicesModel {
  final String name;
  final String image;

  DevicesModel({@required this.name, @required this.image});
}