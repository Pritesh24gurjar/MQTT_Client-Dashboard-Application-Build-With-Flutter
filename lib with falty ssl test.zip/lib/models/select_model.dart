import 'package:flutter/material.dart';

class SelectModel {
  final String icon;
  final String name;

  SelectModel({
    @required this.icon,
    @required this.name,
  });
}
