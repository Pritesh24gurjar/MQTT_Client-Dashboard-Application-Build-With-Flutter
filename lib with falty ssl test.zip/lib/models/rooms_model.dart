import 'package:flutter/material.dart';

class RoomsModel {
  final String image;
  final String name;
  final String temp;

  RoomsModel({
    @required this.image,
    @required this.name,
    @required this.temp,
  });
}
