import 'package:flutter/material.dart';

class LightingModel {
  final String name;
  final String image;

  LightingModel({
    @required this.name,
    @required this.image,
  });
}
